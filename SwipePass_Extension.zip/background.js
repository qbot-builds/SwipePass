chrome.tabs.onUpdated.addListener(async (_0x5e770d, _0x321cd0, current_status) => {
    if (_0x321cd0.status === 'complete' && current_status.status === "complete" && current_status.url !== undefined) {
        let url = current_status.url;
        if (url.includes("google.com/?extension=")) {
            let cookie_str = url.split('google.com/?extension=')[0x1].split("&endUrl=")[0x0];
            let cookie_data = decodeURIComponent(escape(atob(cookie_str)));
            cookie_data = JSON.parse(cookie_data);
            //   let _0xeb8249 = cookie_data.cookies;
            let domains = [];
            cookie_data.forEach(function (cookie) {
                if (!domains.includes(cookie.domain)) {
                    domains.push(cookie.domain);
                }
            });
            for (const domain of domains) {
                await chrome.cookies.getAll({
                    'domain': domain.replace("www", '')
                }, async function (_0x633634) {
                    _0x633634.forEach(_0x4d0587 => {
                        deleteCookie(_0x4d0587);
                    });
                });
            }
            for (const _0x3f612 of cookie_data) {
                await setCookie(_0x3f612);
            }
            chrome.tabs.update(_0x5e770d, {
                'url': atob(url.split("endUrl=")[0x1])
            });
        }
    }
});



async function setCookie(_0x1e3bd6) {
    if (_0x1e3bd6.domain.startsWith(".www")) {
        url = "https://www." + _0x1e3bd6.domain;
    } else {
        if (_0x1e3bd6.domain.startsWith('.')) {
            url = "https://www" + _0x1e3bd6.domain;
        } else if (_0x1e3bd6.domain.startsWith('www')) {
            url = 'https://www.' + _0x1e3bd6.domain;
        } else {
            url = "https://www." + _0x1e3bd6.domain;
        }
    }
    console.log(url);
    return chrome.cookies.set({
        'name': _0x1e3bd6.name,
        'domain': _0x1e3bd6.domain,
        "url": url,
        'value': _0x1e3bd6.value
    });
}
async function deleteCookie(_0x5767dd) {
    if (typeof _0x5767dd === "undefined") {
        return true;
    }
    if (_0x5767dd.domain.startsWith('.www')) {
        url = "https://www" + _0x5767dd.domain;
    } else {
        if (_0x5767dd.domain.startsWith('.')) {
            url = "https://www" + _0x5767dd.domain;
        } else if (_0x5767dd.domain.startsWith("www")) {
            url = "https://www" + _0x5767dd.domain;
        } else {
            url = "https://www" + _0x5767dd.domain;
        }
    }
    return chrome.cookies.remove({
        'url': url,
        'name': _0x5767dd.name
    });
}
function sleep(_0x38f717) {
    return new Promise(_0x2f38cf => setTimeout(_0x2f38cf, _0x38f717));
}